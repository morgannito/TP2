package game;
import game.boardException.IllegalPosition;

/**
 *Chessboard used to play
 */
public class ChessBoard {

    public int[][] cases;

    /**
     *Chessboard constructor, define the Chessboard dimension.
     * @param cases Number of cases in rows and column
     */
    public ChessBoard(int[][] cases) {
        this.cases = cases;
    }

    /**
     *Check if the position is occupied
     * @param pos Position who need to be Checked
     * @return true if the position is occupied else false
     */
    public boolean isOccupied(Coord pos) throws IllegalPosition {
        if (pos.x >= cases.length || pos.y >= cases.length || pos.x < 0 || pos.y < 0) {
            throw new IllegalPosition("Out of range chessboard");
        }
        if (cases[pos.x][pos.y] == 1) {
                return true;
            } else {
                return false;
            }
        }

    /**
     * Set in the chessboard if a case is occupied or not
     * @param pos Case coordinate to alter
     * @param in Set if the case is occupied or not
     */
    public void setOccupation(Coord pos, boolean in) throws IllegalPosition {
        if (pos.x < cases.length && pos.y < cases.length && pos.x >= 0 && pos.y >= 0) {
            if (in) {
                cases[pos.x][pos.y] = 1;
            } else {
                cases[pos.x][pos.y] = 0;
            }
        } else {
            throw new IllegalPosition("Out of chessboard position");
        }
    }

    /**
     * Human display
     */
    public void smartPrint(){
        for(int i = 8; i > 0; i--){
            System.out.print(i);
            for(int i2 = 0; i2 < 8; i2++){
                if (cases[i-1][i2] == 1) {
                    System.out.print(" x ");
                } else {
                    System.out.print("   ");
                }
            }
            System.out.println("");
        }
        System.out.println("  1  2  3  4  5  6  7  8");
    }

}
