package game;

/**
 * Color used by the piece
 */
public enum Color {
        WHITE, BLACK;
    }
