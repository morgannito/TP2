package game;

import game.boardException.IllegalMove;
import game.boardException.IllegalPosition;

/**
 *Mother Class for the chessboard pieces
 */
public abstract class Piece {
    protected Coord place;
    protected ChessBoard board;
    protected Color col;

    /**
     *Piece constructor
     * @param place Piece Coordinate
     * @param board Board used to place the piece
     * @param col Piece color
     */
    public Piece(Coord place, ChessBoard board, Color col) throws IllegalPosition {
        this.place = place;
        this.board = board;
        this.col = col;

        this.board.setOccupation(this.place, true);
    }

    /**
     * Used to make the piece move
     * @param c new coordinate position
     * @throws IllegalMove throws an exception if the piece move is illegal
     */
    public void move(Coord c) throws IllegalMove, IllegalPosition {

    }

    public Coord getPlace() {
        return place;
    }

    public void setPlace(Coord place) {
        this.place = place;
    }

    public ChessBoard getBoard() {
        return board;
    }

    public void setBoard(ChessBoard board) {
        this.board = board;
    }

    public Color getCol() {
        return col;
    }

    public void setCol(Color col) {
        this.col = col;
    }
}
