package appli;

import game.boardException.IllegalPosition;
import game.chessPiece.*;
import game.ChessBoard;
import game.Color;
import game.Coord;

/**
 * Test class
 */
public class Tp1ex3 {
        /**
         * Main class used for the test
         * @param args used for in-line arguments,take no arguments
         * @throws IllegalPosition error in case of illegal position
         */
        public static void main(String[] args) throws IllegalPosition {

                int[][] chess = new int[8][8];
                Coord myCoordinate = new Coord(1, 2);

                //Construction d’un objet de type ChessBoard
                ChessBoard myBoard = new ChessBoard(chess);

                //Construction d'un objet de type bishop,
                Bishop myBishop = new Bishop(myCoordinate, Color.WHITE, myBoard);

                //Test de la méthode d'affichage de l’échiquier.
                myBoard.smartPrint();

                //out of range move
                Coord myMove2 = new Coord(-3, -3);
                myBishop.move(myMove2);
                myBoard.smartPrint();

                //illegal move
                Coord myMove3 = new Coord(5, 5);
                myBishop.move(myMove3);
                myBoard.smartPrint();

                //legal move
                Coord myMove4 = new Coord(2, 3);
                myBishop.move(myMove4);
                myBoard.smartPrint();
        }
}
